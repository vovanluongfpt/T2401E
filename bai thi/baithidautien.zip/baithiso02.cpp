#include <stdio.h>
int main(){
	float sodien,giatien;
		int a;
	printf("1. 3kwh \n");
	printf("2. 80kwh \n");
	printf("3. 120kwh \n");
		printf("nhap lua chon ");
	scanf("%d",&a);
	if(a==1){
	if(sodien=30){
	float tiendien1=sodien*500 ;
		printf("tien dien 30kwh thang nay la %f:",tiendien1);
	}
	}
	if(a==2){

	if(sodien=80){
		float tiendien2=sodien*700;
		printf("tien dien 80 KWH thang nay la %f :",tiendien2);
	}}
	if(a==3){
	
	if(sodien=120){
		float tiendien3=sodien*900;
		printf("tien dien 120KWH la %f :",tiendien3);
	}
}
}

